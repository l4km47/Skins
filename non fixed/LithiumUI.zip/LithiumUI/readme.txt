
Thank you for purchasing our theme and supporting us in the continued development of themes and the open source framework MintUI.
You can learn more about MintUI at GitHub ( https://github.com/CodeRail/MintUI ) or at our website ( http://coderail.com ).

If you have any questions or concerns please feel free to send us an email.
admin@coderail.com

------------------------------------------------------------------------------------------

Rules:
-Do not redistribute the source code, original or modified (please?).
-Do not redistribute the compiled 'LithiumUI.dll' assembly except to end-users of your application.
-Do not attempt to sell the theme or MintUI (kind of implied above, but you know, some people).
-Do not share or otherwise make publicly available the theme ('LithiumUI.dll', again, implied above).

If you respect those rules we'll show our appreciation by continuing development and providing support. Sincerely, thank you to those
who actually do care about this project and what we're trying to accomplish. 

------------------------------------------------------------------------------------------

Setup: Step 1 (Optional):
-In your project's Solution Explorer, right click your project and click 'Add' -> 'New Folder'.
-Name this new folder as 'Includes' (or a name of your own choosing).
-Navigate to your theme assemblies 'MintUI.dll' and 'LithiumUI.dll'.
-Drag and drop these from Windows Explorer into the new folder you created in your project's Solution Explorer.
-These files can now be found in your project's solution folder (e.g. C:\Users\JohnDoe\Documents\Visual Studio 2015\Projects\CoolProgram)
-In the following setup steps, add assembly references from this folder instead of wherever you have downloaded the files to.

Setup: Step 2:
-Open your Project's Properties.
-Navigate to the References tab and click 'Add...'.
-In the Reference Manager dialog click 'Browse..' and add the MintUI.dll and LithiumUI.dll files.
-Close the dialog by pressing 'OK'

Setup: Step 3:
-Open your main form's designer (so that you can see your form)
-Right click your Toolbox and select 'Choose Items..'.
-Navigate to '.NET Framework Components' and click 'Browse..'.
-Select both the MintUI.dll and LithiumUI.dll files and click 'Open'.
-Close the dialog by pressing 'OK'
-The controls should now be listed in the Toolbox under 'All Windows Forms'

Setup: Step 4 (Optional; if you're not using the custom form):
-Set your Form's BackColor to 23, 27, 35

------------------------------------------------------------------------------------------

Using the NavMenu:
-Locate the ClipTabControl in your Toolbox and add it to your form. It's a TabControl with clipped TabPage buttons.
-Right click the ClipTabControl and click 'Select ClipTabControl'.
-In the ClipTabControl properties you can add TabPages as desired and change the visible TabPage using the DesignerSelectedIndex property.
-Add a NavMenu to your form, if you haven't already.
-Set the TabControl property on the NavMenu to the ClipTabControl you just added.
-Add items as desired to the NavMenu and set their TabPage property to an appropriate TabPage on the ClipTabControl.
-Additionally, all NavMenu items should have their IsDropDown properties set to False to be treated as Tabs instead of DropDown buttons (unless you want sub items).
-When running your application you should be able to click the NavMenu items to navigate your TabControl.

------------------------------------------------------------------------------------------

Using the custom Form:
-In the Form designer, select Project in the Visual Studio menu, and enable 'Show All Files'.
-In your solution explorer, find a form you want to apply the custom form skin to (e.g. Form1).
-Now click the drop down arrow on the form to reveal it's hidden files 'Form1.Designer.vb' and 'Form1.resx'.
-Right click the 'Form1.Designer.vb' file and click 'View Code'.
-Find the line at top of this document that says 'Inherits System.Windows.Forms.Form' and change this to 'Inherits LForm'.
-Now save and close the designer. When you run your application it should now have the custom theme applied (only at runtime).

------------------------------------------------------------------------------------------

Troubleshooting:
-If the Form Designer is showing an error message you should make a copy of your project folder, close all Form Designer windows, rebuild your solution, and re-open the form designer(s).
-If the above doesn't work you may be missing the MintUI.dll, make sure it's in the same folder as your executable file and try again.
-If the theme controls are not appearing in your Toolbox you may need to re-add them by following the setup process described above (Step 3).
-If the controls are not showing up in your Toolbox after adding them; try resetting your Toolbox by right clicking it and choosing 'Reset Toolbox', then try again.

------------------------------------------------------------------------------------------

Tips:
-If you want to edit colors try updating the LithiumColors class before attempting to modify individual controls.
-You should merge the MintUI and LithiumUI libraries into your main executable using an obfuscator to prevent people from stealing them.
-When using the NavMenu you may use any TabControl, but it is recommended to use the ClipTabControl.