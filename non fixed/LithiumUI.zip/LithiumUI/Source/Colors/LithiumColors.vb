﻿Public NotInheritable Class LithiumColors

    '??? text: ControlDarkDark
    '??? selected text: 242, 242, 242
    '???: 66, 79, 90
    '??? dark: 52, 63, 72

    ''' <summary>
    ''' Color used to accent alternate elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property AltControlAccent() As Color
        Get
            Return Color.FromArgb(99, 191, 105)
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control shadows.
    ''' </summary>
    Public Shared ReadOnly Property AltControlDark() As Color
        Get
            Return Color.FromArgb(52, 63, 72)
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control faces.
    ''' </summary>
    Public Shared ReadOnly Property AltControl() As Color
        Get
            Return Color.FromArgb(66, 79, 90)
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control highlights.
    ''' </summary>
    Public Shared ReadOnly Property AltControlLight() As Color
        Get
            Return Color.FromArgb(94, 105, 114)
        End Get
    End Property

    ''' <summary>
    ''' Color used for a control's dark text.
    ''' </summary>
    Public Shared ReadOnly Property AltControlTextDark() As Color
        Get
            Return Color.FromArgb(130, 130, 130)
        End Get
    End Property

    ''' <summary>
    ''' Color used for control text.
    ''' </summary>
    Public Shared ReadOnly Property AltControlText() As Color
        Get
            Return Color.FromArgb(193, 193, 193)
        End Get
    End Property

    ''' <summary>
    ''' Color used for a control's light text.
    ''' </summary>
    Public Shared ReadOnly Property AltControlTextLight() As Color
        Get
            Return Color.FromArgb(242, 242, 242)
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccent() As Color
        Get
            Return Color.FromArgb(15, 153, 217) '50, 80, 135
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent darker elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccentDark() As Color
        Get
            Return Color.FromArgb(1, 119, 175) '50, 80, 135
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent lighter elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccentLight() As Color
        Get
            Return Color.FromArgb(17, 179, 255) '50, 80, 135
        End Get
    End Property

    ''' <summary>
    ''' Color used for darker control shadows.
    ''' </summary>
    Public Shared ReadOnly Property ControlDarkDark() As Color
        Get
            Return Color.FromArgb(40, 45, 73) '200, 200, 200
        End Get
    End Property

    ''' <summary>
    ''' Color used for control shadows.
    ''' </summary>
    Public Shared ReadOnly Property ControlDark() As Color
        Get
            Return Color.FromArgb(61, 68, 112) '220, 220, 220
        End Get
    End Property

    ''' <summary>
    ''' Color used for control faces.
    ''' </summary>
    Public Shared ReadOnly Property Control() As Color
        Get
            Return Color.FromArgb(23, 27, 35) '45, 45, 45
        End Get
    End Property

    ''' <summary>
    ''' Color used for control highlights.
    ''' </summary>
    Public Shared ReadOnly Property ControlLight() As Color
        Get
            Return Color.FromArgb(37, 40, 48) '235, 235, 235
        End Get
    End Property

    ''' <summary>
    ''' Color used for lighter control highlights.
    ''' </summary>
    Public Shared ReadOnly Property ControlLightLight() As Color
        Get
            Return Color.FromArgb(255, 255, 255)
        End Get
    End Property

    ''' <summary>
    ''' Color used for control text.
    ''' </summary>
    Public Shared ReadOnly Property ControlText() As Color
        Get
            Return Color.FromArgb(254, 254, 254)
        End Get
    End Property

    ''' <summary>
    ''' Color used for a control's light text.
    ''' </summary>
    Public Shared ReadOnly Property ControlTextLight() As Color
        Get
            Return Color.FromArgb(130, 130, 130)
        End Get
    End Property

    ''' <summary>
    ''' Color used for window client area and text fields.
    ''' </summary>
    Public Shared ReadOnly Property Window() As Color
        Get
            Return Color.FromArgb(17, 21, 27)
        End Get
    End Property

    ''' <summary>
    ''' Color used for text in window client area or text fields.
    ''' </summary>
    Public Shared ReadOnly Property WindowText() As Color
        Get
            Return Color.FromArgb(250, 250, 250)
        End Get
    End Property

    ''' <summary>
    ''' Color used for background of selected items.
    ''' </summary>
    Public Shared ReadOnly Property Highlight() As Color
        Get
            Return Color.FromArgb(130, 230, 255)
        End Get
    End Property

    ''' <summary>
    ''' Color used for text of selected items.
    ''' </summary>
    Public Shared ReadOnly Property HighlightText() As Color
        Get
            Return Color.FromArgb(51, 51, 51)
        End Get
    End Property

    ''' <summary>
    ''' Color used for window frames and control borders.
    ''' </summary>
    Public Shared ReadOnly Property WindowFrame() As Color
        Get
            Return Color.FromArgb(20, 20, 20) '193, 193, 193
        End Get
    End Property

    ''' <summary>
    ''' Color used for the close button on a form.
    ''' </summary>
    Public Shared ReadOnly Property WindowClose() As Color
        Get
            Return Color.FromArgb(232, 17, 35)
        End Get
    End Property

    ''' <summary>
    ''' Color used for the light close button on a form.
    ''' </summary>
    Public Shared ReadOnly Property WindowCloseLight() As Color
        Get
            Return Color.FromArgb(165, 13, 28) '241, 112, 122
        End Get
    End Property

    ''' <summary>
    ''' Color used for the window caption.
    ''' </summary>
    Public Shared ReadOnly Property WindowCaption() As Color
        Get
            Return Color.FromArgb(29, 34, 44)
        End Get
    End Property

End Class
