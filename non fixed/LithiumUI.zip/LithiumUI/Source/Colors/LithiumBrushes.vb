﻿Public NotInheritable Class LithiumBrushes

#Region " Properties "

    ''' <summary>
    ''' Color used to accent alternate elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property AltControlAccent() As SolidBrush
        Get
            Return _AltControlAccent
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control shadows.
    ''' </summary>
    Public Shared ReadOnly Property AltControlDark() As SolidBrush
        Get
            Return _AltControlDark
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control faces.
    ''' </summary>
    Public Shared ReadOnly Property AltControl() As SolidBrush
        Get
            Return _AltControl
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control highlights.
    ''' </summary>
    Public Shared ReadOnly Property AltControlLight() As SolidBrush
        Get
            Return _AltControlLight
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccent() As SolidBrush
        Get
            Return _ControlAccent
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent darker elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccentDark() As SolidBrush
        Get
            Return _ControlAccentDark
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent lighter elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccentLight() As SolidBrush
        Get
            Return _ControlAccentLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for darker control shadows.
    ''' </summary>
    Public Shared ReadOnly Property ControlDarkDark() As SolidBrush
        Get
            Return _ControlDarkDark
        End Get
    End Property

    ''' <summary>
    ''' Color used for control shadows.
    ''' </summary>
    Public Shared ReadOnly Property ControlDark() As SolidBrush
        Get
            Return _ControlDark
        End Get
    End Property

    ''' <summary>
    ''' Color used for control faces.
    ''' </summary>
    Public Shared ReadOnly Property Control() As SolidBrush
        Get
            Return _Control
        End Get
    End Property

    ''' <summary>
    ''' Color used for control highlights.
    ''' </summary>
    Public Shared ReadOnly Property ControlLight() As SolidBrush
        Get
            Return _ControlLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for lighter control highlights.
    ''' </summary>
    Public Shared ReadOnly Property ControlLightLight() As SolidBrush
        Get
            Return _ControlLightLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for control text.
    ''' </summary>
    Public Shared ReadOnly Property ControlText() As SolidBrush
        Get
            Return _ControlText
        End Get
    End Property

    ''' <summary>
    ''' Color used for a control's light text.
    ''' </summary>
    Public Shared ReadOnly Property ControlTextLight() As SolidBrush
        Get
            Return _ControlTextLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for window client area and text fields.
    ''' </summary>
    Public Shared ReadOnly Property Window() As SolidBrush
        Get
            Return _Window
        End Get
    End Property

    ''' <summary>
    ''' Color used for text in window client area or text fields.
    ''' </summary>
    Public Shared ReadOnly Property WindowText() As SolidBrush
        Get
            Return _WindowText
        End Get
    End Property

    ''' <summary>
    ''' Color used for window frames and control borders.
    ''' </summary>
    Public Shared ReadOnly Property WindowFrame() As SolidBrush
        Get
            Return _WindowFrame
        End Get
    End Property

    ''' <summary>
    ''' Color used for background of selected items.
    ''' </summary>
    Public Shared ReadOnly Property Highlight() As SolidBrush
        Get
            Return _Highlight
        End Get
    End Property

    ''' <summary>
    ''' Color used for text of selected items.
    ''' </summary>
    Public Shared ReadOnly Property HighlightText() As SolidBrush
        Get
            Return _HighlightText
        End Get
    End Property

    ''' <summary>
    ''' Color used for the close button on a form.
    ''' </summary>
    Public Shared ReadOnly Property WindowClose() As SolidBrush
        Get
            Return _WindowClose
        End Get
    End Property

    ''' <summary>
    ''' Color used for the light close button on a form.
    ''' </summary>
    Public Shared ReadOnly Property WindowCloseLight() As SolidBrush
        Get
            Return _WindowCloseLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for the window caption.
    ''' </summary>
    Public Shared ReadOnly Property WindowCaption() As SolidBrush
        Get
            Return _WindowCaption
        End Get
    End Property

#End Region

#Region " Members "

    Private Shared _AltControlAccent As SolidBrush
    Private Shared _AltControlDark As SolidBrush
    Private Shared _AltControl As SolidBrush
    Private Shared _AltControlLight As SolidBrush
    Private Shared _ControlAccent As SolidBrush
    Private Shared _ControlAccentDark As SolidBrush
    Private Shared _ControlAccentLight As SolidBrush
    Private Shared _ControlDarkDark As SolidBrush
    Private Shared _ControlDark As SolidBrush
    Private Shared _Control As SolidBrush
    Private Shared _ControlLight As SolidBrush
    Private Shared _ControlLightLight As SolidBrush
    Private Shared _ControlText As SolidBrush
    Private Shared _ControlTextLight As SolidBrush
    Private Shared _Window As SolidBrush
    Private Shared _WindowText As SolidBrush
    Private Shared _WindowFrame As SolidBrush
    Private Shared _Highlight As SolidBrush
    Private Shared _HighlightText As SolidBrush
    Private Shared _WindowClose As SolidBrush
    Private Shared _WindowCloseLight As SolidBrush
    Private Shared _WindowCaption As SolidBrush

#End Region

#Region " Constructor "

    Shared Sub New()
        _AltControlAccent = New SolidBrush(LithiumColors.AltControlAccent)
        _AltControlDark = New SolidBrush(LithiumColors.AltControlDark)
        _AltControl = New SolidBrush(LithiumColors.AltControl)
        _AltControlLight = New SolidBrush(LithiumColors.AltControlLight)
        _ControlAccent = New SolidBrush(LithiumColors.ControlAccent)
        _ControlAccentDark = New SolidBrush(LithiumColors.ControlAccentDark)
        _ControlAccentLight = New SolidBrush(LithiumColors.ControlAccentLight)
        _ControlDarkDark = New SolidBrush(LithiumColors.ControlDarkDark)
        _ControlDark = New SolidBrush(LithiumColors.ControlDark)
        _Control = New SolidBrush(LithiumColors.Control)
        _ControlLight = New SolidBrush(LithiumColors.ControlLight)
        _ControlLightLight = New SolidBrush(LithiumColors.ControlLightLight)
        _ControlText = New SolidBrush(LithiumColors.ControlText)
        _ControlTextLight = New SolidBrush(LithiumColors.ControlTextLight)
        _Window = New SolidBrush(LithiumColors.Window)
        _WindowText = New SolidBrush(LithiumColors.WindowText)
        _WindowFrame = New SolidBrush(LithiumColors.WindowFrame)
        _Highlight = New SolidBrush(LithiumColors.Highlight)
        _HighlightText = New SolidBrush(LithiumColors.HighlightText)
        _WindowClose = New SolidBrush(LithiumColors.WindowClose)
        _WindowCloseLight = New SolidBrush(LithiumColors.WindowCloseLight)
        _WindowCaption = New SolidBrush(LithiumColors.WindowCaption)
    End Sub

#End Region

End Class
