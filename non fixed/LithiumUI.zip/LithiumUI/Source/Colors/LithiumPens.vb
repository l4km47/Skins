﻿Public NotInheritable Class LithiumPens

#Region " Properties "

    ''' <summary>
    ''' Color used to accent alternate elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property AltControlAccent() As Pen
        Get
            Return _AltControlAccent
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control shadows.
    ''' </summary>
    Public Shared ReadOnly Property AltControlDark() As Pen
        Get
            Return _AltControlDark
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control faces.
    ''' </summary>
    Public Shared ReadOnly Property AltControl() As Pen
        Get
            Return _AltControl
        End Get
    End Property

    ''' <summary>
    ''' Color used for alternate control highlights.
    ''' </summary>
    Public Shared ReadOnly Property AltControlLight() As Pen
        Get
            Return _AltControlLight
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccent() As Pen
        Get
            Return _ControlAccent
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent darker elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccentDark() As Pen
        Get
            Return _ControlAccentDark
        End Get
    End Property

    ''' <summary>
    ''' Color used to accent lighter elements (check marks, bullets, etc.).
    ''' </summary>
    Public Shared ReadOnly Property ControlAccentLight() As Pen
        Get
            Return _ControlAccentLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for darker control shadows.
    ''' </summary>
    Public Shared ReadOnly Property ControlDarkDark() As Pen
        Get
            Return _ControlDarkDark
        End Get
    End Property

    ''' <summary>
    ''' Color used for control shadows.
    ''' </summary>
    Public Shared ReadOnly Property ControlDark() As Pen
        Get
            Return _ControlDark
        End Get
    End Property

    ''' <summary>
    ''' Color used for control faces.
    ''' </summary>
    Public Shared ReadOnly Property Control() As Pen
        Get
            Return _Control
        End Get
    End Property

    ''' <summary>
    ''' Color used for control highlights.
    ''' </summary>
    Public Shared ReadOnly Property ControlLight() As Pen
        Get
            Return _ControlLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for lighter control highlights.
    ''' </summary>
    Public Shared ReadOnly Property ControlLightLight() As Pen
        Get
            Return _ControlLightLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for control text.
    ''' </summary>
    Public Shared ReadOnly Property ControlText() As Pen
        Get
            Return _ControlText
        End Get
    End Property

    ''' <summary>
    ''' Color used for a control's light text.
    ''' </summary>
    Public Shared ReadOnly Property ControlTextLight() As Pen
        Get
            Return _ControlTextLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for window client area and text fields.
    ''' </summary>
    Public Shared ReadOnly Property Window() As Pen
        Get
            Return _Window
        End Get
    End Property

    ''' <summary>
    ''' Color used for text in window client area or text fields.
    ''' </summary>
    Public Shared ReadOnly Property WindowText() As Pen
        Get
            Return _WindowText
        End Get
    End Property

    ''' <summary>
    ''' Color used for window frames and control borders.
    ''' </summary>
    Public Shared ReadOnly Property WindowFrame() As Pen
        Get
            Return _WindowFrame
        End Get
    End Property

    ''' <summary>
    ''' Color used for background of selected items.
    ''' </summary>
    Public Shared ReadOnly Property Highlight() As Pen
        Get
            Return _Highlight
        End Get
    End Property

    ''' <summary>
    ''' Color used for text of selected items.
    ''' </summary>
    Public Shared ReadOnly Property HighlightText() As Pen
        Get
            Return _HighlightText
        End Get
    End Property

    ''' <summary>
    ''' Color used for the close button on a form.
    ''' </summary>
    Public Shared ReadOnly Property WindowClose() As Pen
        Get
            Return _WindowClose
        End Get
    End Property

    ''' <summary>
    ''' Color used for the light close button on a form.
    ''' </summary>
    Public Shared ReadOnly Property WindowCloseLight() As Pen
        Get
            Return _WindowCloseLight
        End Get
    End Property

    ''' <summary>
    ''' Color used for the window caption.
    ''' </summary>
    Public Shared ReadOnly Property WindowCaption() As Pen
        Get
            Return _WindowCaption
        End Get
    End Property

#End Region

#Region " Members "

    Private Shared _AltControlAccent As Pen
    Private Shared _AltControlDark As Pen
    Private Shared _AltControl As Pen
    Private Shared _AltControlLight As Pen
    Private Shared _ControlAccent As Pen
    Private Shared _ControlAccentDark As Pen
    Private Shared _ControlAccentLight As Pen
    Private Shared _ControlDarkDark As Pen
    Private Shared _ControlDark As Pen
    Private Shared _Control As Pen
    Private Shared _ControlLight As Pen
    Private Shared _ControlLightLight As Pen
    Private Shared _ControlText As Pen
    Private Shared _ControlTextLight As Pen
    Private Shared _Window As Pen
    Private Shared _WindowText As Pen
    Private Shared _WindowFrame As Pen
    Private Shared _Highlight As Pen
    Private Shared _HighlightText As Pen
    Private Shared _WindowClose As Pen
    Private Shared _WindowCloseLight As Pen
    Private Shared _WindowCaption As Pen

#End Region

#Region " Constructor "

    Shared Sub New()
        _AltControlAccent = New Pen(LithiumColors.AltControlAccent)
        _AltControlDark = New Pen(LithiumColors.AltControlDark)
        _AltControl = New Pen(LithiumColors.AltControl)
        _AltControlLight = New Pen(LithiumColors.AltControlLight)
        _ControlAccent = New Pen(LithiumColors.ControlAccent)
        _ControlAccentDark = New Pen(LithiumColors.ControlAccentDark)
        _ControlAccentLight = New Pen(LithiumColors.ControlAccentLight)
        _ControlDarkDark = New Pen(LithiumColors.ControlDarkDark)
        _ControlDark = New Pen(LithiumColors.ControlDark)
        _Control = New Pen(LithiumColors.Control)
        _ControlLight = New Pen(LithiumColors.ControlLight)
        _ControlLightLight = New Pen(LithiumColors.ControlLightLight)
        _ControlText = New Pen(LithiumColors.ControlText)
        _ControlTextLight = New Pen(LithiumColors.ControlTextLight)
        _Window = New Pen(LithiumColors.Window)
        _WindowText = New Pen(LithiumColors.WindowText)
        _WindowFrame = New Pen(LithiumColors.WindowFrame)
        _Highlight = New Pen(LithiumColors.Highlight)
        _HighlightText = New Pen(LithiumColors.HighlightText)
        _WindowClose = New Pen(LithiumColors.WindowClose)
        _WindowCloseLight = New Pen(LithiumColors.WindowCloseLight)
        _WindowCaption = New Pen(LithiumColors.WindowCaption)
    End Sub

#End Region

End Class
