﻿Public NotInheritable Class LVNavMenu
    Inherits MintVNavMenu

    Public Overrides Sub OnPaintMenuBackground(e As PaintEventArgs)
        MintPaint.FillGradientRectangle(e.Graphics, ClientRectangle, LithiumColors.Window, LithiumColors.WindowFrame, 90.0F)
    End Sub

    Public Overrides Sub OnPaintMenuBorder(e As PaintEventArgs)
        'Do nothing.
    End Sub

    Public Overrides Sub OnPaintMenuItem(e As NavMenuDrawItemEventArgs)
        Dim Selected As Boolean = e.Item.Selected
        Dim DrawArrow As Boolean = e.Item.IsDropDown AndAlso ExpandOnClick

        If e.Item.IsDropDown AndAlso e.Item.Expanded Then
            Selected = False
        End If

        Dim OffsetBounds As Rectangle = e.Bounds
        OffsetBounds.Inflate(-3, -2)

        If Selected Then
            e.Graphics.FillRectangle(LithiumBrushes.ControlDarkDark, OffsetBounds)
            ControlPaint.DrawBorder(e.Graphics, OffsetBounds, LithiumColors.ControlDark, ButtonBorderStyle.Solid)
        ElseIf e.MouseState = MouseState.MouseOver Then
            e.Graphics.FillRectangle(LithiumBrushes.ControlLight, OffsetBounds)
            ControlPaint.DrawBorder(e.Graphics, OffsetBounds, LithiumColors.AltControl, ButtonBorderStyle.Solid)
        End If

        If e.Item.Image IsNot Nothing Then
            If e.Item.Enabled Then
                e.Graphics.DrawImage(e.Item.Image, e.ImageBounds)
            Else
                MintPaint.DrawImageDisabled(e.Graphics, e.Item.Image, e.ImageBounds)
            End If
        End If

        Dim ArrowBounds As Rectangle = e.ArrowBounds
        ArrowBounds.Inflate(-1, -1)
        ArrowBounds.X = e.TextBounds.Right + 5

        If e.Item.Enabled Then
            If DrawArrow Then
                Dim ArrowGlyph As ArrowDirection = ArrowDirection.Right

                If e.Item.Expanded Then
                    ArrowGlyph = ArrowDirection.Down
                End If

                If Selected Then
                    GlyphRenderer.DrawArrowGlyph(e.Graphics, ArrowBounds, ArrowGlyph, LithiumColors.AltControlTextLight)
                Else
                    GlyphRenderer.DrawArrowGlyph(e.Graphics, ArrowBounds, ArrowGlyph, LithiumColors.AltControlText)
                End If
            End If

            If Selected Then
                TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.AltControlTextLight, e.TextFormatFlags)
            Else
                TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.AltControlText, e.TextFormatFlags)
            End If
        Else
            If DrawArrow Then
                If e.Item.Expanded Then
                    GlyphRenderer.DrawArrowGlyph(e.Graphics, ArrowBounds, ArrowDirection.Down, LithiumColors.AltControlTextDark)
                Else
                    GlyphRenderer.DrawArrowGlyph(e.Graphics, ArrowBounds, ArrowDirection.Right, LithiumColors.AltControlTextDark)
                End If
            End If

            TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.AltControlTextDark, e.TextFormatFlags)
        End If
    End Sub

    Public Overrides Sub OnPaintMenuSubItem(e As NavMenuDrawSubItemEventArgs)
        If e.Item.Selected Then
            e.Graphics.FillRectangle(LithiumBrushes.AltControlDark, e.Bounds)
            e.Graphics.FillRectangle(LithiumBrushes.AltControlAccent, 0, e.Bounds.Y, 4, e.Bounds.Height)
        ElseIf e.MouseState = MouseState.MouseOver Then
            e.Graphics.FillRectangle(LithiumBrushes.AltControlLight, e.Bounds)
        End If

        If e.Item.Image IsNot Nothing Then
            If e.Item.Enabled Then
                e.Graphics.DrawImage(e.Item.Image, e.ImageBounds)
            Else
                MintPaint.DrawImageDisabled(e.Graphics, e.Item.Image, e.ImageBounds)
            End If
        End If

        If e.Item.Enabled Then
            If e.Item.Selected Then
                TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.AltControlTextLight, e.TextFormatFlags)
            Else
                TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.AltControlText, e.TextFormatFlags)
            End If
        Else
            TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.AltControlTextDark, e.TextFormatFlags)
        End If
    End Sub

End Class
