﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LRadioButton
    Inherits MintRadioButton

    Public Sub New()
        ForeColor = LithiumColors.ControlText
    End Sub

    Public Overloads Overrides Sub OnPaint(e As CheckBoxPaintEventArgs)
        e.Graphics.Clear(BackColor)
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias

        If Enabled Then
            e.Graphics.FillEllipse(LithiumBrushes.ControlDarkDark, e.CheckBounds)
        Else
            e.Graphics.FillEllipse(LithiumBrushes.WindowCaption, e.CheckBounds)
        End If

        If Enabled Then
            PaintCheckBox(e)
        Else
            PaintCheckBoxDisabled(e)
        End If

        If Enabled Then
            Select Case e.MouseState
                Case MouseState.Normal
                    e.Graphics.DrawEllipse(LithiumPens.ControlAccentDark, e.CheckBounds)
                Case Else
                    e.Graphics.DrawEllipse(LithiumPens.ControlAccent, e.CheckBounds)
            End Select
        Else
            e.Graphics.DrawEllipse(LithiumPens.ControlDark, e.CheckBounds)
        End If
    End Sub

    Private Sub PaintCheckBox(e As CheckBoxPaintEventArgs)
        If Image IsNot Nothing Then
            e.Graphics.DrawImage(Image, e.ImageBounds)
        End If

        If Checked Then
            Dim CheckBounds As Rectangle = e.CheckBounds
            CheckBounds.Inflate(-3, -3)

            e.Graphics.FillEllipse(LithiumBrushes.ControlAccent, CheckBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, ForeColor, e.TextFormatFlags)
    End Sub

    Private Sub PaintCheckBoxDisabled(e As CheckBoxPaintEventArgs)
        If Image IsNot Nothing Then
            MintPaint.DrawImageDisabled(e.Graphics, Image, e.ImageBounds)
        End If

        If Checked Then
            Dim CheckBounds As Rectangle = e.CheckBounds
            CheckBounds.Inflate(-3, -3)

            e.Graphics.FillEllipse(LithiumBrushes.ControlTextLight, CheckBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, LithiumColors.ControlTextLight, e.TextFormatFlags)
    End Sub

End Class
