﻿Public NotInheritable Class LContextMenuStrip
    Inherits MintContextMenuStrip

    Public Overrides Sub OnPaintMenuBackground(e As ToolStripRenderEventArgs)
        e.Graphics.Clear(LithiumColors.ControlLight)
    End Sub

    Public Overrides Sub OnPaintMenuBorder(e As ToolStripRenderEventArgs)
        ControlPaint.DrawBorder(e.Graphics, ClientRectangle, LithiumColors.WindowFrame, ButtonBorderStyle.Solid)
    End Sub

    Public Overrides Sub OnPaintMenuImageMargin(e As ToolStripRenderEventArgs)

    End Sub

    Public Overrides Sub OnPaintSeparator(e As ToolStripSeparatorRenderEventArgs)
        Dim Bounds As Rectangle = e.Item.ContentRectangle
        e.Graphics.DrawLine(LithiumPens.WindowFrame, Bounds.X, Bounds.Y, Bounds.Right, Bounds.Y)
    End Sub

    Public Overrides Sub OnPaintItemArrow(e As ToolStripArrowRenderEventArgs)
        If e.Item.Enabled Then
            GlyphRenderer.DrawArrowGlyph(e.Graphics, e.ArrowRectangle, e.Direction, LithiumColors.ControlText)
        Else
            GlyphRenderer.DrawArrowGlyph(e.Graphics, e.ArrowRectangle, e.Direction, LithiumColors.ControlTextLight)
        End If
    End Sub

    Public Overrides Sub OnPaintItemBackground(e As ToolStripItemRenderEventArgs)
        If e.Item.Enabled AndAlso e.Item.Selected Then
            e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.Item.ContentRectangle)
        Else
            e.Graphics.FillRectangle(LithiumBrushes.ControlLight, e.Item.ContentRectangle)
        End If
    End Sub

    Public Overrides Sub OnPaintItemCheck(e As ToolStripItemImageRenderEventArgs)
        If e.Item.Enabled Then
            GlyphRenderer.DrawCheckGlyph(e.Graphics, e.ImageRectangle, LithiumColors.ControlAccent)
        Else
            GlyphRenderer.DrawCheckGlyph(e.Graphics, e.ImageRectangle, LithiumColors.ControlTextLight)
        End If
    End Sub

    Public Overrides Sub OnPaintItemImage(e As ToolStripItemImageRenderEventArgs)
        If e.Item.Enabled Then
            e.Graphics.DrawImage(e.Image, e.ImageRectangle)
        Else
            MintPaint.DrawImageDisabled(e.Graphics, e.Image, e.ImageRectangle)
        End If
    End Sub

    Public Overrides Sub OnPaintItemText(e As ToolStripItemTextRenderEventArgs)
        If e.Item.Enabled Then
            TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, e.TextRectangle, LithiumColors.ControlText, e.TextFormat)
        Else
            TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, e.TextRectangle, LithiumColors.ControlTextLight, e.TextFormat)
        End If
    End Sub

End Class
