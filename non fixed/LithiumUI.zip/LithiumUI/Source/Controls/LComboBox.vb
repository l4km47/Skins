﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LComboBox
    Inherits MintComboBox

    Public Sub New()
        ForeColor = LithiumColors.ControlText
        BackColor = LithiumColors.Window
    End Sub

    Public Overloads Overrides Sub OnPaint(e As ComboBoxPaintEventArgs)
        e.Graphics.Clear(BackColor)

        Dim BorderBounds As New Rectangle(0, 0, Width - 1, Height - 1)
        Dim BorderPath As GraphicsPath = PathHelper.FilletRectangle(BorderBounds, 1, CornerAlignment.All)

        e.Graphics.SetClip(BorderPath)

        If Enabled Then
            PaintComboBox(e)
        Else
            PaintComboBoxDisabled(e)
        End If

        e.Graphics.ResetClip()
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias

        If Focused Then
            e.Graphics.DrawPath(LithiumPens.ControlDark, BorderPath)
        Else
            e.Graphics.DrawPath(LithiumPens.ControlLight, BorderPath)
        End If

        BorderPath.Dispose()
    End Sub

    Private Sub PaintComboBox(e As ComboBoxPaintEventArgs)
        e.Graphics.Clear(LithiumColors.Window)
     
        Dim ArrowBounds As Rectangle = e.ArrowBounds
        ArrowBounds.Inflate(-3, -3)
        ArrowBounds.X = e.ArrowBounds.X

        Dim TextBounds As Rectangle = e.TextBounds
        TextBounds.X += 5
        TextBounds.Width -= 10

        GlyphRenderer.DrawChevronGlyph(e.Graphics, ArrowBounds, ArrowDirection.Down, ForeColor)
        TextRenderer.DrawText(e.Graphics, Text, Font, TextBounds, ForeColor, e.TextFormatFlags)
    End Sub

    Private Sub PaintComboBoxDisabled(e As ComboBoxPaintEventArgs)
        e.Graphics.Clear(LithiumColors.Control)

        Dim ArrowBounds As Rectangle = e.ArrowBounds
        ArrowBounds.Inflate(-3, -3)
        ArrowBounds.X = e.ArrowBounds.X

        Dim TextBounds As Rectangle = e.TextBounds
        TextBounds.X += 5
        TextBounds.Width -= 10

        GlyphRenderer.DrawChevronGlyph(e.Graphics, ArrowBounds, ArrowDirection.Down, LithiumColors.ControlTextLight)
        TextRenderer.DrawText(e.Graphics, Text, Font, TextBounds, LithiumColors.ControlTextLight, e.TextFormatFlags)
    End Sub

    Public Overrides Sub OnPaintItem(e As ComboBoxDrawItemEventArgs)
        If e.Selected Then
            e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.Bounds) 
        Else
            e.Graphics.FillRectangle(LithiumBrushes.Window, e.Bounds)
        End If

        TextRenderer.DrawText(e.Graphics, e.Text, Font, e.Bounds, LithiumColors.ControlText, e.TextFormatFlags)
    End Sub

End Class
