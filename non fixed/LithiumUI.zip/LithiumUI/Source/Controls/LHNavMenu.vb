﻿Public NotInheritable Class LHNavMenu
    Inherits MintHNavMenu

    Public Sub New()
        ForeColor = LithiumColors.ControlText
    End Sub

    Public Overrides Sub OnPaintMenuBackground(e As PaintEventArgs)
        e.Graphics.Clear(LithiumColors.Control)

        '  e.Graphics.FillRectangle(LithiumBrushes.Window, 0, Height - 1, Width, 1)
    End Sub

    Public Overrides Sub OnPaintMenuBorder(e As PaintEventArgs)
        ' e.Graphics.DrawLine(LithiumPens.WindowFrame, 0, 0, Width, 0)
        e.Graphics.DrawLine(LithiumPens.WindowFrame, 0, Height - 1, Width, Height - 1)
    End Sub

    Public Overrides Sub OnPaintMenuItem(e As NavMenuDrawItemEventArgs)
        'If e.Item.Selected Then
        '    e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.Bounds)
        '    '  e.Graphics.FillRectangle(LithiumBrushes.AltControlAccent, e.Bounds.X, e.Bounds.Bottom - 4, e.Bounds.Width, 4)
        'ElseIf e.MouseState = MouseState.MouseOver Then
        '    e.Graphics.FillRectangle(LithiumBrushes.ControlLight, e.Bounds)
        'End If

        If e.Item.Image IsNot Nothing Then
            If e.Item.Enabled Then
                e.Graphics.DrawImage(e.Item.Image, e.ImageBounds)
            Else
                MintPaint.DrawImageDisabled(e.Graphics, e.Item.Image, e.ImageBounds)
            End If
        End If

        Dim ArrowBounds As Rectangle = e.ArrowBounds
        ArrowBounds.Inflate(-1, -1)

        If e.Item.Enabled Then
            If e.Item.IsDropDown Then
                GlyphRenderer.DrawArrowGlyph(e.Graphics, ArrowBounds, ArrowDirection.Down, ForeColor)
            End If

            If e.Item.Selected Then
                TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.ControlText, e.TextFormatFlags)
            ElseIf e.MouseState = MouseState.MouseOver Then
                TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.AltControlText, e.TextFormatFlags)
            Else
                TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.AltControlTextDark, e.TextFormatFlags)
            End If
        Else
            If e.Item.IsDropDown Then
                GlyphRenderer.DrawArrowGlyph(e.Graphics, ArrowBounds, ArrowDirection.Down, LithiumColors.ControlTextLight)
            End If

            TextRenderer.DrawText(e.Graphics, e.Item.Text, e.Item.Font, e.TextBounds, LithiumColors.ControlTextLight, e.TextFormatFlags)
        End If
    End Sub

    Public Overrides Sub OnPaintDropDownBackground(e As ToolStripRenderEventArgs)
        e.Graphics.Clear(LithiumColors.ControlLight)
    End Sub

    Public Overrides Sub OnPaintDropDownBorder(e As ToolStripRenderEventArgs)
        ControlPaint.DrawBorder(e.Graphics, e.AffectedBounds, LithiumColors.WindowFrame, ButtonBorderStyle.Solid)
    End Sub

    Public Overrides Sub OnPaintSubItemBackground(e As ToolStripItemRenderEventArgs)
        If e.Item.Enabled AndAlso e.Item.Selected Then
            e.Graphics.FillRectangle(LithiumBrushes.ControlLight, e.Item.ContentRectangle)
        Else
            e.Graphics.FillRectangle(LithiumBrushes.Control, e.Item.ContentRectangle)
        End If
    End Sub

    Public Overrides Sub OnPaintSubItemText(e As ToolStripItemTextRenderEventArgs)
        If e.Item.Enabled Then
            If e.Item.Selected Then
                TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, e.TextRectangle, LithiumColors.HighlightText, e.TextFormat)
            Else
                TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, e.TextRectangle, LithiumColors.ControlText, e.TextFormat)
            End If
        Else
            TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, e.TextRectangle, LithiumColors.ControlTextLight, e.TextFormat)
        End If
    End Sub

    Public Overrides Sub OnPaintDropDownImageMargin(e As ToolStripRenderEventArgs)
        'Do nothing.
    End Sub

    Public Overrides Sub OnPaintSubItemImage(e As ToolStripItemImageRenderEventArgs)
        If e.Item.Enabled Then
            e.Graphics.DrawImage(e.Image, e.ImageRectangle)
        Else
            MintPaint.DrawImageDisabled(e.Graphics, e.Image, e.ImageRectangle)
        End If
    End Sub

End Class
