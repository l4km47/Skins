﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LToggleSwitch
    Inherits MintToggleSwitch

    Public Overloads Overrides Sub OnPaint(e As ToggleSwitchPaintEventArgs)
        e.Graphics.Clear(BackColor)

        Dim BorderBounds As Rectangle = ClientRectangle
        BorderBounds.Width -= 1
        BorderBounds.Height -= 1

        Dim BorderPath As GraphicsPath = PathHelper.ChamferRectangle(BorderBounds, 3, CornerAlignment.BottomLeft)
        e.Graphics.SetClip(BorderPath)

        If Enabled Then
            PaintToggleSwitch(e)
        Else
            PaintToggleSwitchDisabled(e)
        End If

        e.Graphics.ResetClip()

        If Enabled Then
            Select Case e.MouseState
                Case MouseState.Normal
                    e.Graphics.DrawPath(LithiumPens.ControlAccentDark, BorderPath)
                Case Else
                    e.Graphics.DrawPath(LithiumPens.ControlAccent, BorderPath)
            End Select
        Else
            e.Graphics.DrawPath(LithiumPens.ControlDark, BorderPath)
        End If

        BorderPath.Dispose()
    End Sub

    Private Sub PaintToggleSwitch(e As ToggleSwitchPaintEventArgs)
        If Checked Then
            e.Graphics.Clear(LithiumColors.ControlDarkDark)
            TextRenderer.DrawText(e.Graphics, "On", Font, ClientRectangle, LithiumColors.ControlAccent, TextFormatFlags.VerticalCenter Or TextFormatFlags.HorizontalCenter)
        Else
            e.Graphics.Clear(LithiumColors.Control)
            TextRenderer.DrawText(e.Graphics, "Off", Font, ClientRectangle, LithiumColors.ControlDark, TextFormatFlags.VerticalCenter Or TextFormatFlags.HorizontalCenter)
        End If
    End Sub

    Private Sub PaintToggleSwitchDisabled(e As ToggleSwitchPaintEventArgs)
        If Checked Then
            e.Graphics.Clear(LithiumColors.ControlDarkDark)
            TextRenderer.DrawText(e.Graphics, "On", Font, ClientRectangle, LithiumColors.ControlAccentDark, TextFormatFlags.VerticalCenter Or TextFormatFlags.HorizontalCenter)
        Else
            e.Graphics.Clear(LithiumColors.Control)
            TextRenderer.DrawText(e.Graphics, "Off", Font, ClientRectangle, LithiumColors.ControlDark, TextFormatFlags.VerticalCenter Or TextFormatFlags.HorizontalCenter)
        End If
    End Sub

End Class
