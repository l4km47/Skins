﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LProgressBar
    Inherits MintProgressBar

    Public Overloads Overrides Sub OnPaint(e As ProgressBarPaintEventArgs)
        e.Graphics.Clear(LithiumColors.Window)
 
        If Enabled Then
            MintPaint.FillGradientRectangle(e.Graphics, e.ProgressBounds, LithiumColors.ControlAccentDark, LithiumColors.ControlAccentLight, 0.0F) 
        Else
            e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.ProgressBounds)
        End If
    End Sub

End Class
