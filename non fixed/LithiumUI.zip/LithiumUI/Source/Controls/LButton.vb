﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LButton
    Inherits MintButton

    Public Sub New()
        ForeColor = LithiumColors.ControlText
    End Sub

    Public Overloads Overrides Sub OnPaint(e As ButtonPaintEventArgs)
        e.Graphics.Clear(BackColor)

        Dim BorderBounds As New Rectangle(0, 0, Width - 1, Height - 1)
        Dim BorderPath As GraphicsPath = PathHelper.FilletRectangle(BorderBounds, 2, CornerAlignment.All)
        e.Graphics.SetClip(BorderPath)

        If Enabled Then
            PaintButton(e)
        Else
            PaintButtonDisabled(e)
        End If

        e.Graphics.ResetClip()
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias

        If Enabled Then
            e.Graphics.DrawPath(LithiumPens.ControlAccent, BorderPath)
        Else
            e.Graphics.DrawPath(LithiumPens.ControlLight, BorderPath)
        End If

        BorderPath.Dispose()
    End Sub

    Private Sub PaintButton(e As ButtonPaintEventArgs)
        Select Case e.MouseState
            Case MouseState.MouseOver
                MintPaint.FillGradientRectangle(e.Graphics, ClientRectangle, LithiumColors.ControlAccentLight, LithiumColors.ControlAccent, 90.0F)
            Case MouseState.MouseDown
                MintPaint.FillGradientRectangle(e.Graphics, ClientRectangle, LithiumColors.ControlAccentDark, LithiumColors.ControlAccent, 90.0F)
            Case Else
                MintPaint.FillGradientRectangle(e.Graphics, ClientRectangle, LithiumColors.ControlAccent, LithiumColors.ControlAccentDark, 90.0F)
        End Select

        If Image IsNot Nothing Then
            e.Graphics.DrawImage(Image, e.ImageBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, ForeColor, e.TextFormatFlags)
    End Sub

    Private Sub PaintButtonDisabled(e As ButtonPaintEventArgs)
        e.Graphics.Clear(LithiumColors.WindowCaption)

        If Image IsNot Nothing Then
            MintPaint.DrawImageDisabled(e.Graphics, Image, e.ImageBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, LithiumColors.ControlTextLight, e.TextFormatFlags)
    End Sub

End Class
