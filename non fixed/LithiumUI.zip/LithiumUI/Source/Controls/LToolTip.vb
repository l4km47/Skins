﻿Public NotInheritable Class LToolTip
    Inherits MintToolTip

    Public Overrides Sub OnPaint(e As ToolTipPaintEventArgs)
        e.Graphics.Clear(LithiumColors.ControlLight)

        Dim Icon As Image = Nothing

        Select Case ToolTipIcon
            Case Windows.Forms.ToolTipIcon.Warning
                Icon = My.Resources.ico_warning
            Case Windows.Forms.ToolTipIcon.Info
                Icon = My.Resources.ico_info
            Case Windows.Forms.ToolTipIcon.Error
                Icon = My.Resources.ico_error
        End Select

        If Icon IsNot Nothing Then
            e.Graphics.DrawImage(Icon, e.IconBounds)
        End If

        Select Case ToolTipIcon
            Case Windows.Forms.ToolTipIcon.Warning, Windows.Forms.ToolTipIcon.Error
                TextRenderer.DrawText(e.Graphics, ToolTipTitle, e.TitleFont, e.TitleBounds, LithiumColors.ControlTextLight, e.TitleFormatFlags)
            Case Else
                TextRenderer.DrawText(e.Graphics, ToolTipTitle, e.TitleFont, e.TitleBounds, LithiumColors.AltControlAccent, e.TitleFormatFlags)
        End Select

        TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, e.TextBounds, LithiumColors.ControlText, e.TextFormatFlags)

        ControlPaint.DrawBorder(e.Graphics, e.Bounds, LithiumColors.WindowFrame, ButtonBorderStyle.Solid)
    End Sub

End Class
