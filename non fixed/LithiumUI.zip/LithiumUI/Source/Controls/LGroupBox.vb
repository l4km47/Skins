﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LGroupBox
    Inherits MintGroupBox

    Public Overloads Overrides Sub OnPaint(e As GroupBoxPaintEventArgs)
        e.Graphics.Clear(BackColor)

        Dim CenterLine As Integer = e.HeaderBounds.Height \ 2

        Dim BorderBounds As New Rectangle(0, CenterLine, Width - 1, Height - CenterLine - 1)
        Dim BorderPath As GraphicsPath = PathHelper.FilletRectangle(BorderBounds, 3, CornerAlignment.All)

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias
        e.Graphics.DrawPath(LithiumPens.ControlDarkDark, BorderPath)

        BorderPath.Dispose()

        If Enabled Then
            TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, LithiumColors.ControlDark, BackColor, e.TextFormatFlags)
        Else
            TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, LithiumColors.ControlTextLight, BackColor, e.TextFormatFlags)
        End If
    End Sub

End Class
