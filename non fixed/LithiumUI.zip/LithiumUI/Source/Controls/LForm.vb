﻿Public Class LForm
    Inherits MintForm

    Public Sub New()
        MyBase.ModernFrame = True

        BackColor = LithiumColors.Control
        Font = New Font("Verdana", 9.0F)
    End Sub

    Public Overrides Sub OnPaintCaption(e As FormPaintCaptionEventArgs)
        e.Graphics.Clear(LithiumColors.Control)

        MintPaint.FillGradientRectangle(e.Graphics, e.Bounds, LithiumColors.WindowCaption, LithiumColors.Control, 45.0F, True)

        If e.RenderIcon Then
            e.Graphics.DrawIcon(CaptionIcon, e.IconBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, LithiumColors.ControlText, e.TextFormatFlags)

        If e.RenderMinMaxButtons Then
            If MaximizeBox Then
                Select Case e.MaximizeButtonMouseState
                    Case MouseState.MouseDown
                        e.Graphics.FillRectangle(LithiumBrushes.ControlDarkDark, e.MaximizeButtonBounds)
                    Case MouseState.MouseOver
                        e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.MaximizeButtonBounds)
                End Select
            End If

            Dim MaxGlyph As WindowGlyph = WindowGlyph.Maximize

            If WindowState = FormWindowState.Maximized Then
                MaxGlyph = WindowGlyph.Restore
            End If

            Dim MaxBounds As Rectangle = e.MaximizeButtonBounds
            MaxBounds.Inflate(-9, -9)

            If MaximizeBox Then
                GlyphRenderer.DrawWindowGlyph(e.Graphics, MaxBounds, MaxGlyph, LithiumColors.ControlText)
            Else
                GlyphRenderer.DrawWindowGlyph(e.Graphics, MaxBounds, MaxGlyph, LithiumColors.ControlDarkDark)
            End If

            If MinimizeBox Then
                Select Case e.MinimizeButtonMouseState
                    Case MouseState.MouseDown
                        e.Graphics.FillRectangle(LithiumBrushes.ControlDarkDark, e.MinimizeButtonBounds)
                    Case MouseState.MouseOver
                        e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.MinimizeButtonBounds)
                End Select
            End If

            Dim MinBounds As Rectangle = e.MinimizeButtonBounds
            MinBounds.Inflate(-9, -9)

            If MinimizeBox Then
                If e.MinimizeButtonMouseState = MouseState.Normal Then
                    GlyphRenderer.DrawWindowGlyph(e.Graphics, MinBounds, WindowGlyph.Minimize, LithiumColors.ControlText)
                Else
                    GlyphRenderer.DrawWindowGlyph(e.Graphics, MinBounds, WindowGlyph.Minimize, LithiumColors.ControlText)
                End If
            Else
                GlyphRenderer.DrawWindowGlyph(e.Graphics, MinBounds, WindowGlyph.Minimize, LithiumColors.ControlDarkDark)
            End If
        End If

        If e.RenderCloseButton Then
            Select Case e.CloseButtonMouseState
                Case MouseState.MouseDown
                    e.Graphics.FillRectangle(LithiumBrushes.WindowCloseLight, e.CloseButtonBounds)
                Case MouseState.MouseOver
                    e.Graphics.FillRectangle(LithiumBrushes.WindowClose, e.CloseButtonBounds)
            End Select

            Dim CloseBounds As Rectangle = e.CloseButtonBounds
            CloseBounds.Inflate(-9, -9)

            If e.CloseButtonMouseState = MouseState.Normal Then
                GlyphRenderer.DrawWindowGlyph(e.Graphics, CloseBounds, WindowGlyph.Close, LithiumColors.ControlText)
            Else
                GlyphRenderer.DrawWindowGlyph(e.Graphics, CloseBounds, WindowGlyph.Close, LithiumColors.ControlLightLight)
            End If
        End If

        If WindowState = FormWindowState.Normal Then
            Dim Bounds As New Rectangle(0, 0, Width, Height)
            Dim InnerBounds As Rectangle = Bounds
            InnerBounds.Inflate(-1, -1)

            ControlPaint.DrawBorder(e.Graphics, Bounds, LithiumColors.WindowFrame, ButtonBorderStyle.Solid)
            ControlPaint.DrawBorder(e.Graphics, InnerBounds, LithiumColors.ControlLight, ButtonBorderStyle.Solid)
        End If
    End Sub

    Public Overrides Sub OnPaintFrame(e As FormPaintFrameEventArgs)
        e.Graphics.Clear(LithiumColors.Control)

        If WindowState = FormWindowState.Normal Then
            Dim Bounds As New Rectangle(0, 0, Width, Height)
            Dim InnerBounds As Rectangle = Bounds
            InnerBounds.Inflate(-1, -1)

            ControlPaint.DrawBorder(e.Graphics, Bounds, LithiumColors.WindowFrame, ButtonBorderStyle.Solid)
            ControlPaint.DrawBorder(e.Graphics, InnerBounds, LithiumColors.ControlLight, ButtonBorderStyle.Solid)
        End If    
    End Sub

    Public Overrides Sub OnLayoutCaption(e As FormLayoutCaptionEventArgs)
        Dim OffsetY As Integer = e.IconBounds.Y - e.FrameSize
        Dim OffsetX As Integer = e.IconBounds.X - e.FrameSize

        Dim IconBounds As Rectangle = e.IconBounds
        IconBounds.Offset(-OffsetX, -OffsetY)

        Dim TextBounds As Rectangle = e.TextBounds
        TextBounds.Y -= OffsetY

        Dim CloseBounds As Rectangle = e.CloseButtonBounds
        CloseBounds.Width = 35
        CloseBounds.Height = e.Bounds.Height + e.FrameSize
        CloseBounds.Y = ((e.Bounds.Height + e.FrameSize) \ 2) - (CloseBounds.Height \ 2)
        CloseBounds.X = e.Bounds.Right - CloseBounds.Width + e.FrameSize

        Dim MaxBounds As Rectangle = CloseBounds
        MaxBounds.X -= CloseBounds.Width

        Dim MinBounds As Rectangle = MaxBounds
        MinBounds.X -= MaxBounds.Width

        e.IconBounds = IconBounds
        e.TextBounds = TextBounds
        e.CloseButtonBounds = CloseBounds
        e.MaximizeButtonBounds = MaxBounds
        e.MinimizeButtonBounds = MinBounds
    End Sub

End Class
