﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LTrackBar
    Inherits MintTrackBar

    Public Overloads Overrides Sub OnPaint(e As TrackBarPaintEventArgs)
        e.Graphics.Clear(BackColor)

        If Not TickStyle = Windows.Forms.TickStyle.None Then
            PaintTicks(e)
        End If

        PaintTrack(e)
        PaintThumb(e)
    End Sub

    Private Sub PaintTicks(e As TrackBarPaintEventArgs)
        Dim TickBounds As Rectangle

        Select Case TickStyle
            Case Windows.Forms.TickStyle.TopLeft
                If Orientation = Windows.Forms.Orientation.Horizontal Then
                    TickBounds = New Rectangle(0, e.ThumbBounds.Y - 10, Width, 7)
                Else
                    TickBounds = New Rectangle(0, 0, 7, Height)
                End If
            Case Windows.Forms.TickStyle.BottomRight
                If Orientation = Windows.Forms.Orientation.Horizontal Then
                    TickBounds = New Rectangle(0, e.ThumbBounds.Bottom + 2, Width, 7)
                Else
                    TickBounds = New Rectangle(e.ThumbBounds.Right + 2, 0, 7, Height)
                End If
            Case Else
                If Orientation = Windows.Forms.Orientation.Horizontal Then
                    TickBounds = New Rectangle(0, e.ThumbBounds.Y - 10, Width, e.ThumbBounds.Height + 19)
                Else
                    TickBounds = New Rectangle(e.ThumbBounds.X - 10, 0, e.ThumbBounds.Width + 19, Height)
                End If
        End Select

        If Orientation = Windows.Forms.Orientation.Horizontal Then
            e.Graphics.ExcludeClip(New Rectangle(0, e.ThumbBounds.Y - 2, Width, e.ThumbBounds.Height + 4))

            For I As Integer = 0 To e.TickPositions.Length - 1
                Dim X As Integer = e.TickPositions(I)
                e.Graphics.DrawLine(LithiumPens.ControlDark, X, TickBounds.Y, X, TickBounds.Bottom)
            Next

            Dim LeftTick As Integer = e.ChannelBounds.X + (e.ThumbBounds.Size.Width \ 2)
            Dim RightTick As Integer = e.ChannelBounds.Right - (e.ThumbBounds.Size.Width \ 2)

            e.Graphics.DrawLine(LithiumPens.ControlDarkDark, LeftTick, TickBounds.Y, LeftTick, TickBounds.Bottom)
            e.Graphics.DrawLine(LithiumPens.ControlDarkDark, RightTick, TickBounds.Y, RightTick, TickBounds.Bottom)
        Else
            e.Graphics.ExcludeClip(New Rectangle(e.ThumbBounds.X - 2, 0, e.ThumbBounds.Width + 4, Height))

            For I As Integer = 0 To e.TickPositions.Length - 1
                Dim Y As Integer = e.TickPositions(I)
                e.Graphics.DrawLine(LithiumPens.ControlDark, TickBounds.X, Y, TickBounds.Right, Y)
            Next

            Dim TopTick As Integer = e.ChannelBounds.Y + (e.ThumbBounds.Size.Height \ 2)
            Dim BottomTick As Integer = e.ChannelBounds.Bottom - (e.ThumbBounds.Size.Height \ 2)

            e.Graphics.DrawLine(LithiumPens.ControlDark, TickBounds.X, TopTick, TickBounds.Right, TopTick)
            e.Graphics.DrawLine(LithiumPens.ControlDark, TickBounds.X, BottomTick, TickBounds.Right, BottomTick)
        End If

        e.Graphics.ResetClip()
    End Sub

    Private Sub PaintTrack(e As TrackBarPaintEventArgs)
        e.Graphics.FillRectangle(LithiumBrushes.Window, e.ChannelBounds)

        If Enabled Then
            MintPaint.FillGradientRectangle(e.Graphics, e.ProgressBounds, LithiumColors.ControlAccentDark, LithiumColors.ControlAccentLight, 0.0F)
        Else
            e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.ProgressBounds)
        End If
    End Sub

    Private Sub PaintThumb(e As TrackBarPaintEventArgs)
        Dim BorderBounds As Rectangle = e.ThumbBounds
        BorderBounds.Width -= 1
        BorderBounds.Height -= 1

        Dim BorderPath As GraphicsPath = PathHelper.FilletRectangle(BorderBounds, 2, CornerAlignment.All)
        e.Graphics.SetClip(BorderPath)

        If Enabled Then
            Select Case e.MouseState
                Case MouseState.MouseOver
                    MintPaint.FillGradientRectangle(e.Graphics, ClientRectangle, LithiumColors.ControlAccentLight, LithiumColors.ControlAccent, 90.0F)
                Case MouseState.MouseDown
                    MintPaint.FillGradientRectangle(e.Graphics, ClientRectangle, LithiumColors.ControlAccentDark, LithiumColors.ControlAccent, 90.0F)
                Case Else
                    MintPaint.FillGradientRectangle(e.Graphics, ClientRectangle, LithiumColors.ControlAccent, LithiumColors.ControlAccentDark, 90.0F)
            End Select
        Else
            e.Graphics.Clear(LithiumColors.ControlDark)
        End If

        e.Graphics.ResetClip()
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias

        e.Graphics.DrawPath(LithiumPens.Control, BorderPath)

        BorderPath.Dispose()
    End Sub

End Class
