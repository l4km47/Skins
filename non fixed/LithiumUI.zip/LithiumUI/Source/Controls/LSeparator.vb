﻿Public NotInheritable Class LSeparator
    Inherits MintSeparator

    Public Overloads Overrides Sub OnPaint(e As SeparatorPaintEventArgs)
        e.Graphics.Clear(BackColor)

        Dim CenterLine As Integer = Height \ 2

        e.Graphics.DrawLine(LithiumPens.ControlDarkDark, 0, CenterLine, Width, CenterLine)

        If Enabled Then
            TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, LithiumColors.ControlDark, BackColor, e.TextFormatFlags)
        Else
            TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, LithiumColors.ControlTextLight, BackColor, e.TextFormatFlags)
        End If
    End Sub

End Class
