﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LNumericUpDown
    Inherits MintNumericUpDown

    Public Sub New()
        ForeColor = LithiumColors.WindowText
        BackColor = LithiumColors.Window
        Padding = New Padding(4, 3, 4, 3)
    End Sub

    Public Overloads Overrides Sub OnPaint(e As NumericUpDownPaintEventArgs)
        e.Graphics.Clear(LithiumColors.Window)

        Select Case e.UpButtonMouseState
            Case MouseState.MouseOver
                e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.UpButtonBounds)
            Case MouseState.MouseDown
                e.Graphics.FillRectangle(LithiumBrushes.ControlDarkDark, e.UpButtonBounds)
        End Select

        Select Case e.DownButtonMouseState
            Case MouseState.MouseOver
                e.Graphics.FillRectangle(LithiumBrushes.ControlDark, e.DownButtonBounds)
            Case MouseState.MouseDown
                e.Graphics.FillRectangle(LithiumBrushes.ControlDarkDark, e.DownButtonBounds)
        End Select

        If Enabled Then
            PaintArrowButtons(e)
        Else
            PaintArrowButtonsDisabled(e)
        End If
    End Sub

    Public Overrides Sub OnPaintFrame(e As NumericUpDownPaintFrameEventArgs)
        e.Graphics.Clear(BackColor)

        Dim BorderBounds As New Rectangle(0, 0, Width - 1, Height - 1)
        Dim BorderPath As GraphicsPath = PathHelper.FilletRectangle(BorderBounds, 1, CornerAlignment.All)

        e.Graphics.FillPath(LithiumBrushes.Window, BorderPath)

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias

        If Focused Then
            e.Graphics.DrawPath(LithiumPens.ControlDark, BorderPath)
        Else
            e.Graphics.DrawPath(LithiumPens.ControlLight, BorderPath)
        End If

        BorderPath.Dispose()
    End Sub

    Private Sub PaintArrowButtons(e As NumericUpDownPaintEventArgs)
        Dim UpBounds As Rectangle = e.UpButtonBounds
        UpBounds.Inflate(-1, -1)

        Dim DownBounds As Rectangle = e.DownButtonBounds
        DownBounds.Inflate(-1, -1)

        GlyphRenderer.DrawChevronGlyph(e.Graphics, UpBounds, ArrowDirection.Up, ForeColor)
        GlyphRenderer.DrawChevronGlyph(e.Graphics, DownBounds, ArrowDirection.Down, ForeColor)
    End Sub

    Private Sub PaintArrowButtonsDisabled(e As NumericUpDownPaintEventArgs)
        Dim UpBounds As Rectangle = e.UpButtonBounds
        UpBounds.Inflate(-1, -1)

        Dim DownBounds As Rectangle = e.DownButtonBounds
        DownBounds.Inflate(-1, -1)

        GlyphRenderer.DrawChevronGlyph(e.Graphics, UpBounds, ArrowDirection.Up, LithiumColors.ControlTextLight)
        GlyphRenderer.DrawChevronGlyph(e.Graphics, DownBounds, ArrowDirection.Down, LithiumColors.ControlTextLight)
    End Sub

End Class
