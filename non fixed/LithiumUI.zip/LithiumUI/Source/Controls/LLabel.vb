﻿Public NotInheritable Class LLabel
    Inherits MintLabel

    Public Sub New()
        ForeColor = LithiumColors.ControlText
    End Sub

    Public Overloads Overrides Sub OnPaint(e As LabelPaintEventArgs)
        e.Graphics.Clear(BackColor)

        If Enabled Then
            PaintLabel(e)
        Else
            PaintLabelDisabled(e)
        End If
    End Sub

    Private Sub PaintLabel(e As LabelPaintEventArgs)
        If Image IsNot Nothing Then
            e.Graphics.DrawImage(Image, e.ImageBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.Bounds, ForeColor, e.TextFormatFlags)
    End Sub

    Private Sub PaintLabelDisabled(e As LabelPaintEventArgs)
        If Image IsNot Nothing Then
            MintPaint.DrawImageDisabled(e.Graphics, Image, e.ImageBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.Bounds, LithiumColors.ControlTextLight, e.TextFormatFlags)
    End Sub

End Class
