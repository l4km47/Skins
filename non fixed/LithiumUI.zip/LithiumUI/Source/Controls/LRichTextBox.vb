﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LRichTextBox
    Inherits MintRichTextBox

    Public Sub New()
        ForeColor = LithiumColors.WindowText
        BackColor = LithiumColors.Window
        Padding = New Padding(4, 4, 4, 4)
    End Sub

    Public Overloads Overrides Sub OnPaintFrame(e As TextBoxPaintFrameEventArgs)
        e.Graphics.Clear(BackColor)

        Dim BorderBounds As New Rectangle(0, 0, Width - 1, Height - 1)
        Dim BorderPath As GraphicsPath = PathHelper.FilletRectangle(BorderBounds, 1, CornerAlignment.All)

        e.Graphics.FillPath(LithiumBrushes.Window, BorderPath)

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias

        If Focused Then
            e.Graphics.DrawPath(LithiumPens.ControlDark, BorderPath)
        Else
            e.Graphics.DrawPath(LithiumPens.ControlLight, BorderPath)
        End If

        BorderPath.Dispose()
    End Sub

End Class
