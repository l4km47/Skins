﻿Imports System.Drawing.Drawing2D

Public NotInheritable Class LCheckBox
    Inherits MintCheckBox

    Public Sub New()
        ForeColor = LithiumColors.ControlText
    End Sub

    Public Overloads Overrides Sub OnPaint(e As CheckBoxPaintEventArgs)
        e.Graphics.Clear(BackColor)

        Dim BorderBounds As Rectangle = e.CheckBounds
        BorderBounds.Width -= 1
        BorderBounds.Height -= 1

        Dim BorderPath As GraphicsPath = PathHelper.FilletRectangle(BorderBounds, 1, CornerAlignment.All)

        If Enabled Then
            e.Graphics.FillPath(LithiumBrushes.ControlDarkDark, BorderPath)
        Else
            e.Graphics.FillPath(LithiumBrushes.WindowCaption, BorderPath)
        End If

        If Enabled Then
            PaintCheckBox(e)
        Else
            PaintCheckBoxDisabled(e)
        End If

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias

        If Enabled Then
            Select Case e.MouseState
                Case MouseState.Normal
                    e.Graphics.DrawPath(LithiumPens.ControlAccentDark, BorderPath)
                Case Else
                    e.Graphics.DrawPath(LithiumPens.ControlAccent, BorderPath)
            End Select
        Else
            e.Graphics.DrawPath(LithiumPens.ControlLight, BorderPath)
        End If

        BorderPath.Dispose()
    End Sub

    Private Sub PaintCheckBox(e As CheckBoxPaintEventArgs)
        If Image IsNot Nothing Then
            e.Graphics.DrawImage(Image, e.ImageBounds)
        End If

        If CheckState = Windows.Forms.CheckState.Checked Then
            GlyphRenderer.DrawCheckGlyph(e.Graphics, e.CheckBounds, LithiumColors.ControlAccent)
        ElseIf CheckState = Windows.Forms.CheckState.Indeterminate Then
            Dim CheckBounds As Rectangle = e.CheckBounds
            CheckBounds.Inflate(-3, -3)

            e.Graphics.FillRectangle(LithiumBrushes.ControlAccent, CheckBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, ForeColor, e.TextFormatFlags)
    End Sub

    Private Sub PaintCheckBoxDisabled(e As CheckBoxPaintEventArgs)
        If Image IsNot Nothing Then
            MintPaint.DrawImageDisabled(e.Graphics, Image, e.ImageBounds)
        End If

        If CheckState = Windows.Forms.CheckState.Checked Then
            GlyphRenderer.DrawCheckGlyph(e.Graphics, e.CheckBounds, LithiumColors.ControlTextLight)
        ElseIf CheckState = Windows.Forms.CheckState.Indeterminate Then
            Dim CheckBounds As Rectangle = e.CheckBounds
            CheckBounds.Inflate(-3, -3)

            e.Graphics.FillRectangle(LithiumBrushes.ControlTextLight, CheckBounds)
        End If

        TextRenderer.DrawText(e.Graphics, Text, Font, e.TextBounds, LithiumColors.ControlTextLight, e.TextFormatFlags)
    End Sub

End Class
